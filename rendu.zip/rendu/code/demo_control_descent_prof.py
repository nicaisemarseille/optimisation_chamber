# -*- coding: utf-8 -*-


import matplotlib.pyplot
import numpy
import os
import math

import _env
import preprocessing
import processing
import postprocessing
import descent_gradient
import projected_chi



def your_optimization_procedure(domain_omega, spacestep, omega, f, f_dir, f_neu, f_rob,
                           beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob,
                           Alpha, mu, chi, V_obj,prop):
    """

    Parameter:
        cf solvehelmholtz's remarks
        Alpha: complex, it corresponds to the absorbtion coefficient;
        mu: float, it is the initial step of the gradient's descent;
        V_obj: float, it characterizes the volume constraint on the density chi.
    """
    chi = projected_chi.compute_projected(chi, domain_omega, V_obj)
    wavenumber = omega/(3e8)
    k = 0
    (M, N) = numpy.shape(domain_omega)
    numb_iter = 200
    energy = numpy.zeros((numb_iter+1, 1), dtype=numpy.float64)
    while k < numb_iter and mu > 10**(-5):
        print('---- iteration number = ', k)
        print('1. computing solution of Helmholtz problem, i.e., u')
        u = processing.solve_helmholtz(domain_omega, spacestep, wavenumber, f, f_dir, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob)
        print('2. computing solution of adjoint problem, i.e., p')
        one = numpy.ones((M,N))
        f_p = -2 * (one + mask_omega_interest)*u.conj()
        f_dir_p = numpy.zeros((M, N), dtype=numpy.complex128)
        p = processing.solve_helmholtz(domain_omega, spacestep, wavenumber, f_p, f_dir_p, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob)

        print('3. computing objective function, i.e., energy')
        ene = your_compute_objective_function(domain_omega, u, spacestep)
        energy[k] = ene
        print('4. computing parametric gradient')
        grad =  (Alpha*u*p).real
        while ene >= energy[k] and mu > 10 ** -5:
            print('    a. computing gradient descent')
            chi = descent_gradient.compute_gradient_descent(chi, grad, domain_omega, mu)
            print('    b. computing projected gradient')
            chi = projected_chi.compute_projected(chi, domain_omega, V_obj)
            print('    c. computing solution of Helmholtz problem, i.e., u')
            alpha_rob = Alpha * chi
            u = processing.solve_helmholtz(domain_omega, spacestep, wavenumber, f, f_dir, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob)
            print('    d. computing objective function, i.e., energy (E)')
            ene = your_compute_objective_function(domain_omega, u, spacestep)
            if ene<energy[k]:
                # The step is increased if the energy decreased
                mu = mu * 1.1
            else:
                # The step is decreased is the energy increased
                mu = mu / 2
        k += 1

    print('end. computing solution of Helmholtz problem, i.e., u')
    
    return chi, energy, u, grad


def your_optimization_procedure_2freq(domain_omega, spacestep, omega_1,omega_2, f, f_dir, f_neu, f_rob,
                           beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_1,alpha_rob_2,
                           Alpha_1,Alpha_2, mu, chi, V_obj,prop=0.5):
    """

    Parameter:
        cf solvehelmholtz's remarks
        Alpha: complex, it corresponds to the absorbtion coefficient;
        mu: float, it is the initial step of the gradient's descent;
        V_obj: float, it characterizes the volume constraint on the density chi.
    """
    chi = projected_chi.compute_projected(chi, domain_omega, V_obj)
    wavenumber_1 = omega_1/(3e8)
    wavenumber_2 = omega_2/(3e8)
    k = 0
    (M, N) = numpy.shape(domain_omega)
    numb_iter = 200
    energy = numpy.zeros((numb_iter+1, 1), dtype=numpy.float64)
    while k < numb_iter and mu > 10**(-5):
        print('---- iteration number = ', k)
        print('1. computing solution of Helmholtz problem, i.e., u')
        u_1 = processing.solve_helmholtz(domain_omega, spacestep, wavenumber_1, f, f_dir, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_1)
        u_2 = processing.solve_helmholtz(domain_omega, spacestep, wavenumber_2, f, f_dir, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_2)
        print('2. computing solution of adjoint problem, i.e., p')
        one = numpy.ones((M,N))
        f_p_1 = -2 * (one + mask_omega_interest)*u_1.conj()
        f_p_2 =  -2 * (one + mask_omega_interest)*u_2.conj()
        f_dir_p = numpy.zeros((M, N), dtype=numpy.complex128)
        p_1 = processing.solve_helmholtz(domain_omega, spacestep, wavenumber_1, f_p_1, f_dir_p, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_1)
        p_2 = processing.solve_helmholtz(domain_omega, spacestep, wavenumber_2, f_p_2, f_dir_p, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_2)
        print('3. computing objective function, i.e., energy')
        ene = your_compute_objective_function(domain_omega, u_1, spacestep)+your_compute_objective_function(domain_omega, u_2, spacestep)
        energy[k] = ene
        print('4. computing parametric gradient')
        grad =  (Alpha_1*u_1*p_1).real + (Alpha_2*u_2*p_2).real
        while ene >= energy[k] and mu > 10 ** -5:
            print('    a. computing gradient descent')
            chi = descent_gradient.compute_gradient_descent(chi, grad, domain_omega, mu)
            print('    b. computing projected gradient')
            chi = projected_chi.compute_projected(chi, domain_omega, V_obj)
            print('    c. computing solution of Helmholtz problem, i.e., u')
            alpha_rob_1 = Alpha_1 * chi
            alpha_rob_2 = Alpha_2 * chi 
            u_1 = processing.solve_helmholtz(domain_omega, spacestep, wavenumber_1, f, f_dir, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_1)
            u_2 = processing.solve_helmholtz(domain_omega, spacestep, wavenumber_2, f, f_dir, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_2)
            print('    d. computing objective function, i.e., energy (E)')
            ene = your_compute_objective_function(domain_omega, u_1, spacestep)+your_compute_objective_function(domain_omega, u_2, spacestep)
            if ene<energy[k]:
                # The step is increased if the energy decreased
                mu = mu * 1.1
            else:
                # The step is decreased is the energy increased
                mu = mu / 2
        k += 1

    print('end. computing solution of Helmholtz problem, i.e., u')
    
    return chi, energy, u_1, grad

def your_optimization_procedure_multifreq(domain_omega, spacestep, omega_list, f, f_dir, f_neu, f_rob,
                                          beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, Alpha_list,
                                          mu, chi, V_obj, prop=0.5):
    """
    Parameters:
        domain_omega, spacestep, etc.: See solvehelmholtz's remarks.
        Alpha_list: list of complex values, each corresponding to the absorption coefficient for each frequency.
        mu: float, the initial step of the gradient's descent.
        V_obj: float, volume constraint on the density chi.
    """
    chi = projected_chi.compute_projected(chi, domain_omega, V_obj)
    (M, N) = numpy.shape(domain_omega)
    numb_iter = 200
    energy = numpy.zeros((numb_iter + 1, 1), dtype=numpy.float64)
    k = 0

    while k < numb_iter and mu > 10**(-5):
        print('---- iteration number = ', k)
        total_energy = 0
        total_grad = numpy.zeros((M, N), dtype=numpy.float64)
        
        for idx, omega in enumerate(omega_list):
            print(f'1. computing solution of Helmholtz problem for frequency {omega}')
            wavenumber = omega / (3e8)
            alpha_rob = Alpha_list[idx] * chi

            # Résolution du problème direct
            u = processing.solve_helmholtz(domain_omega, spacestep, wavenumber, f, f_dir, f_neu, f_rob,
                                           beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob)

            # Résolution du problème adjoint
            one = numpy.ones((M, N))
            f_p = -2 * (one + mask_omega_interest) * u.conj()
            f_dir_p = numpy.zeros((M, N), dtype=numpy.complex128)
            p = processing.solve_helmholtz(domain_omega, spacestep, wavenumber, f_p, f_dir_p, f_neu, f_rob,
                                           beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob)

            total_energy += your_compute_objective_function(domain_omega, u, spacestep)
            total_grad += (Alpha_list[idx] * u * p).real

        energy[k] = total_energy
        print('3. Total energy =', total_energy)

        # Vérification de l'amélioration de l'énergie
        while total_energy >= energy[k] and mu > 10 ** -5:
            print('    a. computing gradient descent')
            chi = descent_gradient.compute_gradient_descent(chi, total_grad, domain_omega, mu)
            print('    b. computing projected gradient')
            chi = projected_chi.compute_projected(chi, domain_omega, V_obj)

            # Recalcul de l'énergie après la descente du gradient
            total_energy = 0
            for idx, omega in enumerate(omega_list):
                wavenumber = omega / (3e8)
                alpha_rob = Alpha_list[idx] * chi
                u = processing.solve_helmholtz(domain_omega, spacestep, wavenumber, f, f_dir, f_neu, f_rob,
                                               beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob)
                total_energy += your_compute_objective_function(domain_omega, u, spacestep)

            print('    d. Total energy after gradient descent =', total_energy)
            
            if total_energy < energy[k]:
                mu = mu * 1.1  # Augmenter le pas si l'énergie diminue
            else:
                mu = mu / 2    # Réduire le pas si l'énergie augmente

        k += 1

    print('end. computing solution of Helmholtz problem')
    return chi, energy, u, total_grad

def your_compute_objective_function(domain_omega,  u, spacestep):
    """

    Parameter:
        domain_omega: Matrix (NxP), it defines the domain and the shape of the
        Robin frontier;
        u: Matrix (NxP), it is the solution of the Helmholtz problem, we are
        computing its energy;
        spacestep: float, it corresponds to the step used to solve the Helmholtz
        equation.
    """
    N,p= numpy.shape(domain_omega)

    # On ne calcule l'intégrale que sur les points qui sont dans le domaine omega puis omega_interest
    # (où domain_omega == -1 pour domain_omega)
    mask_omega = (domain_omega == -1)


    n_indices_interst = round(4.2/10 * p) 
    i = (p - n_indices_interst) // 2 
    j = i + n_indices_interst

    # Création du masque de omega_interest
    mask_position = numpy.zeros_like(domain_omega, dtype=bool)  
    mask_position[i:j+1, i:j+1] = True  
    mask_omega = (domain_omega == -1)
    
    # Combinaison des deux masques
    mask_omega_interest = mask_omega & mask_position

    u_squared = numpy.abs(u) ** 2
    
    integral_omega = u_squared * mask_omega
    integral_omega_interest = u_squared * mask_omega_interest
    
    # Calcul de l'intégrale par la méthode des rectangles
    # On multiplie par spacestep^2 car c'est une intégrale 2D
    energy = numpy.sum(integral_omega) * (spacestep ** 2) + numpy.sum(integral_omega_interest) * (spacestep ** 2)
    
    return energy


import numpy

def project_sur_indicatrice(chi, domain_omega, V_obj):
    M, N = numpy.shape(domain_omega)
    lk = [(i, j) for i in range(M) for j in range(N) if domain_omega[i, j] == _env.NODE_ROBIN]
    n = len(lk)
    cible = V_obj * n
    chi_values_robin = [chi[i, j] for (i, j) in lk]
    
    s_min, s_max = min(chi_values_robin), max(chi_values_robin)
    
    tol = 1e-6 
    while (s_max - s_min) > tol:
        s_mid = (s_min + s_max) / 2

        chi_2 = numpy.zeros((M, N))
        for (i, j) in lk:
            chi_2[i, j] = 1 if chi[i, j] >= s_mid else 0

        somme_actuelle = numpy.sum(chi_2)
        
        if somme_actuelle < cible:
            s_max = s_mid
        elif somme_actuelle > cible:
            s_min = s_mid
        else:
            break

    for (i, j) in lk:
        chi_2[i, j] = 1 if chi[i, j] >= s_mid else 0

    return chi_2



if __name__ == '__main__':

 
    N = 100  
    M = 2 * N  
    level = 3 #ordre fractalee
    spacestep = 1.0 / N  # mesh size



    omega_1 = 2*numpy.pi * 1e9
    omega_2 = 2*numpy.pi * 1.273e9
    omega_list = [omega_1]
    # omega = 2*numpy.pi * 1.59e8
    wavenumber_1 = omega_1/(3e8)
    wavenumber_2 = omega_2/(3e8)
    # -- proportion absorbant
    prop = 0.3


    beta_pde, alpha_pde, alpha_dir, beta_neu, alpha_rob, beta_rob = preprocessing._set_coefficients_of_pde(M, N)


    f, f_dir, f_neu, f_rob = preprocessing._set_rhs_of_pde(M, N)

    # -- set geometry of domain
    domain_omega, x, y, _, _ = preprocessing._set_geometry_of_domain(M, N, level)

    
    S = 0
    for i in range(0, M):
        for j in range(0, N):
            if domain_omega[i, j] == _env.NODE_ROBIN:
                S += 1
    
    V_0 = 1  # initial volume of the domain
     # constraint on the density
    chi = numpy.zeros((M, N), dtype=numpy.float64)
    for i in range(0,10):
        chi[:,i] = 1
        chi[:,N-1-i] = 1
          # surface of the fractal  
   
    # Masque pour les points où `domain_omega == _env.NODE_ROBIN`
    # mask_key = (domain_omega == _env.NODE_ROBIN)

    # mask_columns = ((numpy.arange(N) >= j0) & (numpy.arange(N) < j1)) | ((numpy.arange(N) >= j2) & (numpy.arange(N) <= j3))

    # chi[:, :] = mask_key & mask_columns[numpy.newaxis, :]
    # numpy.savetxt('chi_new.txt',chi,fmt="%d")
    
    #chi = numpy.ones((M,N))
    mask_omega = (domain_omega == -1)

    n_indices_interst = round(4.2/10 * N) 
    i = (N - n_indices_interst) // 2 
    j = i + n_indices_interst

    # Création du masque de omega_interest
    mask_position = numpy.zeros_like(domain_omega, dtype=bool)  
    mask_position[i:j+1, i:j+1] = True  
    
    mask_omega_interest = mask_omega & mask_position
    chi = numpy.zeros((M, N), dtype=numpy.float64)
    j0,j1,j2,j3 = 0 , N //3 , 2*N //3 , N-1
    mask_key = (domain_omega == _env.NODE_ROBIN)

    mask_columns = ((numpy.arange(N) >= j0) & (numpy.arange(N) < j1)) | ((numpy.arange(N) >= j2) & (numpy.arange(N) <= j3))

    chi[:, :] = mask_key & mask_columns[numpy.newaxis, :]
    #chi =preprocessing._set_chi(M,N,x,y)
    chi = preprocessing.set2zero(chi, domain_omega)


    numpy.savetxt("chi_proj.txt", chi)  


    V_obj = numpy.sum(numpy.sum(chi)) / S
    mu = 5 
    mu1 = 10**(-5)  

    # Masque pour le domaine omega
    mask_omega = (domain_omega == -1)

    n_indices_interst = round(4.2/10 * N) 
    i = (N - n_indices_interst) // 2 
    j = i + n_indices_interst
    mask_position[i:j+1, i:j+1] = True  
    
    mask_omega_interest = mask_omega & mask_position
    


    f_dir[:, :] = 0.0
    f_dir[0, 0:N] = 1.0
    #f_dir[:, :] = 0.0
    #f_dir[0, int(N/2)] = 10.0


    import compute_alpha_vf

    Alpha_1 = compute_alpha_vf.compute_alpha(omega_1,"Absorbing material")[0]
    Alpha_2 = compute_alpha_vf.compute_alpha(omega_2,"Absorbing material")[0]
    Alpha_list = [compute_alpha_vf.compute_alpha(omega,"Absorbing material")[0] for omega in omega_list]
    alpha_rob_1 = Alpha_1 * chi
    alpha_rob_2 = Alpha_2 * chi




    # -- Solution du problème d'Helmoltz : u
    u_1 = processing.solve_helmholtz(domain_omega, spacestep, wavenumber_1, f, f_dir, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_1)
    u_2 = processing.solve_helmholtz(domain_omega, spacestep, wavenumber_2, f, f_dir, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_2)

    # -- solution du problème adjoint : p
    one = numpy.ones((M,N))
    f_p_1 = -2 * (one + mask_omega_interest)*u_1.conj()
    f_dir_p = numpy.zeros((M, N), dtype=numpy.complex128)
    p_1 = processing.solve_helmholtz(domain_omega, spacestep, wavenumber_1, f_p_1, f_dir_p, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_1)
    f_p_2 = -2 * (one + mask_omega_interest)*u_2.conj()
    # -- Calcul du gradient en conséquence : grad
    p_2 = processing.solve_helmholtz(domain_omega, spacestep, wavenumber_2, f_p_2, f_dir_p, f_neu, f_rob,
                        beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_2)
    grad = (Alpha_1*u_1*p_1).real + (Alpha_2*u_2*p_2).real
    numpy.savetxt("grad.txt", grad, fmt="%.2f")  

    # -- On conserve chi0, u0 pour les plots
    chi0 = chi.copy()
    u0 = u_1.copy()
    
        

    energy = numpy.zeros((100+1, 1), dtype=numpy.float64)
    chi, energy, u, grad = your_optimization_procedure_multifreq(domain_omega, spacestep, omega_list, f, f_dir, f_neu, f_rob,
                                          beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, Alpha_list,
                                          mu, chi, V_obj, prop=0.5)
    chin = preprocessing.set2zero(chi.copy(), domain_omega)
    un = u.copy()

    chi_2 = project_sur_indicatrice(chin,domain_omega,V_obj)

    alpha_rob_2 = Alpha_2 * chi_2
    u2 = processing.solve_helmholtz(domain_omega, spacestep, wavenumber_1, f, f_dir, f_neu, f_rob,
                                    beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_1)
    postprocessing._plot_uncontroled_solution(u0, chi0)
    postprocessing._plot_controled_solution(un, chin)
    postprocessing._plot_charachteristic_solution(u2, chi_2)
    err = un - u0
    postprocessing._plot_error(err)
    postprocessing._plot_energy_history(energy)
    print("énergie de u0:-------------------",your_compute_objective_function(domain_omega, u0, spacestep))
    print("\n")
    print("énergie de u_n:--------------------",your_compute_objective_function(domain_omega, un, spacestep))
    # omega_min = 2 * numpy.pi * 1e7
    # omega_max = 2 * numpy.pi * 2e9
    # omegas = numpy.linspace(omega_min, omega_max, num=200) 

    # objective_values_0 = []
    # objective_values_n = []
    # objective_values_2 = []
    # for omega in omegas:
    #     wavenumber = omega/(3e8)
    #     Alpha = compute_alpha_vf.compute_alpha(omega, "Absorbing material")[0]
    #     alpha_rob_0 = Alpha * chi0
    #     alpha_rob_n = Alpha * chin
         
    #     u = processing.solve_helmholtz(domain_omega, spacestep, wavenumber, f, f_dir, f_neu, f_rob,
    #                                 beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_0)
        
    #     objective_value_0 = your_compute_objective_function(domain_omega, u, spacestep)
    #     objective_values_0.append(objective_value_0)

    #     u = processing.solve_helmholtz(domain_omega, spacestep, wavenumber, f, f_dir, f_neu, f_rob,
    #                                 beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_n)
        
    #     objective_value_n = your_compute_objective_function(domain_omega, u, spacestep)
    #     objective_values_n.append(objective_value_n)

    #     chi_2 = project_sur_indicatrice(chin,domain_omega,V_obj)
    #     alpha_rob_2 = Alpha * chi_2
    #     u = processing.solve_helmholtz(domain_omega, spacestep, wavenumber, f, f_dir, f_neu, f_rob,
    #                                 beta_pde, alpha_pde, alpha_dir, beta_neu, beta_rob, alpha_rob_2)
    #     objective_value_2 = your_compute_objective_function(domain_omega, u, spacestep)
    #     objective_values_2.append(objective_value_2)
    # matplotlib.pyplot.figure(figsize=(10, 6))
    # matplotlib.pyplot.plot(omegas, objective_values_0, label="Energie (chi0)", color="blue")
    # matplotlib.pyplot.plot(omegas, objective_values_n, label="Energie  (chin)", color="red")
    # matplotlib.pyplot.plot(omegas, objective_values_2, label="Energie (chin characteristic)", color="green")
    # matplotlib.pyplot.xlabel(r"$\omega$ (rad/s)")
    # matplotlib.pyplot.ylabel("Energie")
    # matplotlib.pyplot.title("Valeurs de l'énergie en fonction de Omega")
    # matplotlib.pyplot.legend()
    # matplotlib.pyplot.grid(True)
    # matplotlib.pyplot.show()
    # print('End.',V_obj)